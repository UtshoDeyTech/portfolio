# Portfolio Data Backup
Created: 2025-11-11 21:41:51

## Contents:
- json_data/: All database models exported as JSON
- blogs_markdown/: Blog posts in Markdown format
- media_files/: All uploaded media files (images, documents, etc.)
- manifest.json: Backup metadata

## To Restore:
1. Upload this zip file to your Django admin panel
2. Go to: /admin/portfolio-import/
3. Select the zip file and click "Import"
4. All data will be restored to the database

## Models Included:
- Education Entries: 4
- Experience Entries: 6
- Projects: 6
- Research Publications: 2
- Blog Posts: 0
- Media Files: 1
- Home Page Data: 1

WARNING: Importing will overwrite existing data!
