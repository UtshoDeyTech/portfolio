# Portfolio Data Backup
Created: 2025-11-16 16:47:11

## Contents:
- json_data/: All database models exported as JSON
- blogs_markdown/: Blog posts in Markdown format (if any)
- media_files/: All uploaded media files (images, documents, etc.)
- manifest.json: Backup metadata

## To Restore:
1. Upload this zip file to your Django admin panel
2. Go to: /admin/api/backuprestore/
3. Select the zip file and click "Import Data"
4. All data will be restored to the database

## Models Included:
- HomeData: 1
- NewsletterSubscriber: 1
- ResearchIcon: 7
- BlogsData: 1
- BlogSettings: 1
- EducationEntry: 4
- ExperienceEntry: 6
- Project: 6
- ResearchPublication: 2
- MediaFile: 1
- Blog: 5
- BlogComment: 0
- BlogView: 7
- BlogLike: 1

WARNING: Importing will overwrite existing data!
